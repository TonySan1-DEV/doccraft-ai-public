/*
  # Fix documents table schema for proper file upload

  1. Changes
    - Ensure filename column exists and is properly configured
    - Add any missing columns that the upload logic expects
    - Update RLS policies to work with the current schema
    
  2. Security
    - Maintain RLS policies for user data isolation
*/

-- Ensure the documents table has all required columns
DO $$
BEGIN
  -- Check if filename column exists, if not add it
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'documents' AND column_name = 'filename'
  ) THEN
    ALTER TABLE documents ADD COLUMN filename text NOT NULL;
  END IF;

  -- Add enhancements column if it doesn't exist
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'documents' AND column_name = 'enhancements'
  ) THEN
    ALTER TABLE documents ADD COLUMN enhancements jsonb;
  END IF;

  -- Add processed_at column if it doesn't exist
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'documents' AND column_name = 'processed_at'
  ) THEN
    ALTER TABLE documents ADD COLUMN processed_at timestamptz;
  END IF;
END $$;

-- Create index on filename for better performance
CREATE INDEX IF NOT EXISTS documents_filename_idx ON documents(filename);
CREATE INDEX IF NOT EXISTS documents_user_id_idx ON documents(user_id);

-- Update RLS policies to ensure they work correctly
DROP POLICY IF EXISTS "Users can read own documents" ON documents;
DROP POLICY IF EXISTS "Users can insert own documents" ON documents;
DROP POLICY IF EXISTS "Users can update own documents" ON documents;
DROP POLICY IF EXISTS "Users can delete own documents" ON documents;

-- Create comprehensive RLS policies
CREATE POLICY "Users can read own documents"
  ON documents
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own documents"
  ON documents
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own documents"
  ON documents
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own documents"
  ON documents
  FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);