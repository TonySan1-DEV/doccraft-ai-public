/*
  # Add missing columns to documents table

  1. Changes
    - Add `original_name` column to store original filename
    - Add `file_path` column to store storage path
    - Add `file_type` column to store file extension
    - Add `file_size` column to store file size in bytes
    - Add `extracted_text` column to store extracted content
    - Add `status` column to track processing status
    - Add `updated_at` column with trigger for automatic updates
    
  2. Notes
    - Uses IF NOT EXISTS checks to prevent errors if columns already exist
    - Adds appropriate indexes for performance
    - Creates trigger for updated_at column
*/

-- Add missing columns to documents table
DO $$
BEGIN
  -- Add original_name column
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'documents' AND column_name = 'original_name'
  ) THEN
    ALTER TABLE documents ADD COLUMN original_name text NOT NULL DEFAULT '';
  END IF;

  -- Add file_path column
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'documents' AND column_name = 'file_path'
  ) THEN
    ALTER TABLE documents ADD COLUMN file_path text NOT NULL DEFAULT '';
  END IF;

  -- Add file_type column
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'documents' AND column_name = 'file_type'
  ) THEN
    ALTER TABLE documents ADD COLUMN file_type text NOT NULL DEFAULT '';
  END IF;

  -- Add file_size column
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'documents' AND column_name = 'file_size'
  ) THEN
    ALTER TABLE documents ADD COLUMN file_size bigint NOT NULL DEFAULT 0;
  END IF;

  -- Add extracted_text column
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'documents' AND column_name = 'extracted_text'
  ) THEN
    ALTER TABLE documents ADD COLUMN extracted_text text;
  END IF;

  -- Add status column
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'documents' AND column_name = 'status'
  ) THEN
    ALTER TABLE documents ADD COLUMN status text DEFAULT 'uploaded' NOT NULL;
  END IF;

  -- Add updated_at column
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'documents' AND column_name = 'updated_at'
  ) THEN
    ALTER TABLE documents ADD COLUMN updated_at timestamptz DEFAULT now() NOT NULL;
  END IF;
END $$;

-- Remove default values for columns that shouldn't have them
ALTER TABLE documents ALTER COLUMN original_name DROP DEFAULT;
ALTER TABLE documents ALTER COLUMN file_path DROP DEFAULT;
ALTER TABLE documents ALTER COLUMN file_type DROP DEFAULT;
ALTER TABLE documents ALTER COLUMN file_size DROP DEFAULT;

-- Create indexes for better performance if they don't exist
CREATE INDEX IF NOT EXISTS documents_status_idx ON documents(status);
CREATE INDEX IF NOT EXISTS documents_file_type_idx ON documents(file_type);

-- Create updated_at trigger function if it doesn't exist
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

-- Create trigger for updated_at column
DROP TRIGGER IF EXISTS update_documents_updated_at ON documents;
CREATE TRIGGER update_documents_updated_at
  BEFORE UPDATE ON documents
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();