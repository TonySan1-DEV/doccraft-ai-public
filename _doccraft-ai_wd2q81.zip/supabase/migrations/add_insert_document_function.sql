/*
  # Add insert_document RPC function

  1. Functions
    - `insert_document` - RPC function to insert documents bypassing schema cache issues
    
  2. Purpose
    - Provides a reliable way to insert documents when schema cache is not synchronized
    - Returns the inserted document data
    - Handles all required fields for the documents table
*/

-- Create RPC function to insert documents
CREATE OR REPLACE FUNCTION insert_document(
  p_user_id uuid,
  p_original_name text,
  p_file_path text,
  p_file_type text,
  p_file_size bigint,
  p_extracted_text text DEFAULT NULL,
  p_status text DEFAULT 'uploaded'
)
RETURNS TABLE(
  id uuid,
  user_id uuid,
  original_name text,
  file_path text,
  file_type text,
  file_size bigint,
  extracted_text text,
  status text,
  created_at timestamptz,
  updated_at timestamptz
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  new_doc_id uuid;
BEGIN
  -- Insert the document
  INSERT INTO documents (
    user_id,
    original_name,
    file_path,
    file_type,
    file_size,
    extracted_text,
    status
  ) VALUES (
    p_user_id,
    p_original_name,
    p_file_path,
    p_file_type,
    p_file_size,
    p_extracted_text,
    p_status
  ) RETURNING documents.id INTO new_doc_id;

  -- Return the inserted document
  RETURN QUERY
  SELECT 
    d.id,
    d.user_id,
    d.original_name,
    d.file_path,
    d.file_type,
    d.file_size,
    d.extracted_text,
    d.status,
    d.created_at,
    d.updated_at
  FROM documents d
  WHERE d.id = new_doc_id;
END;
$$;

-- Grant execute permission to authenticated users
GRANT EXECUTE ON FUNCTION insert_document TO authenticated;