/*
  # Fix raw SQL executor function syntax

  1. Functions
    - `execute_raw_sql` - Fixed function to execute raw SQL with parameters
    
  2. Changes
    - Fixed syntax error with dynamic SQL execution
    - Proper handling of RETURNING clause
    - Better parameter substitution
*/

-- Drop the existing function
DROP FUNCTION IF EXISTS execute_raw_sql(text, jsonb);

-- Create corrected function to execute raw SQL with parameters
CREATE OR REPLACE FUNCTION execute_raw_sql(
  sql_query text,
  params jsonb DEFAULT '[]'::jsonb
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  result jsonb;
  param_count int;
  i int;
  query_with_params text;
  temp_result record;
  results jsonb := '[]'::jsonb;
BEGIN
  -- Get parameter count
  param_count := jsonb_array_length(params);
  query_with_params := sql_query;
  
  -- Replace parameter placeholders with actual values
  FOR i IN 0..param_count-1 LOOP
    query_with_params := replace(
      query_with_params, 
      '$' || (i + 1)::text, 
      quote_literal(params->i->>0)
    );
  END LOOP;
  
  -- Execute the query and collect results
  FOR temp_result IN EXECUTE query_with_params LOOP
    results := results || jsonb_build_array(row_to_json(temp_result));
  END LOOP;
  
  RETURN results;
END;
$$;

-- Grant execute permission to authenticated users
GRANT EXECUTE ON FUNCTION execute_raw_sql TO authenticated;