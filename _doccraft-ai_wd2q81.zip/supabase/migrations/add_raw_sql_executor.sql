/*
  # Add raw SQL executor function

  1. Functions
    - `execute_raw_sql` - Function to execute raw SQL with parameters
    
  2. Purpose
    - Completely bypasses schema cache by executing raw SQL
    - Handles parameterized queries safely
    - Returns query results directly
*/

-- Create function to execute raw SQL with parameters
CREATE OR REPLACE FUNCTION execute_raw_sql(
  sql_query text,
  params jsonb DEFAULT '[]'::jsonb
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  result jsonb;
  param_count int;
  i int;
  query_with_params text;
BEGIN
  -- Get parameter count
  param_count := jsonb_array_length(params);
  query_with_params := sql_query;
  
  -- Replace parameter placeholders with actual values
  FOR i IN 0..param_count-1 LOOP
    query_with_params := replace(
      query_with_params, 
      '$' || (i + 1)::text, 
      quote_literal(params->i->>0)
    );
  END LOOP;
  
  -- Execute the query and return results as JSON
  EXECUTE 'SELECT jsonb_agg(row_to_json(t)) FROM (' || query_with_params || ') t' INTO result;
  
  RETURN COALESCE(result, '[]'::jsonb);
END;
$$;

-- Grant execute permission to authenticated users
GRANT EXECUTE ON FUNCTION execute_raw_sql TO authenticated;