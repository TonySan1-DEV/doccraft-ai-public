/*
  # Add image source tracking to images table

  1. Changes
    - Add `source` column to track image origin (ai, stock, upload)
    - Add `source_metadata` column for additional source information
    - Add indexes for better performance
    
  2. Notes
    - Uses IF NOT EXISTS checks to prevent errors if columns already exist
    - Adds appropriate constraints and defaults
*/

-- Add source column to images table
DO $$
BEGIN
  -- Add source column
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'images' AND column_name = 'source'
  ) THEN
    ALTER TABLE images ADD COLUMN source text DEFAULT 'ai' NOT NULL;
  END IF;

  -- Add source_metadata column for storing additional source info
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'images' AND column_name = 'source_metadata'
  ) THEN
    ALTER TABLE images ADD COLUMN source_metadata jsonb DEFAULT '{}' NOT NULL;
  END IF;
END $$;

-- Add check constraint for valid source values
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.check_constraints
    WHERE constraint_name = 'images_source_check'
  ) THEN
    ALTER TABLE images ADD CONSTRAINT images_source_check 
    CHECK (source IN ('ai', 'stock', 'upload'));
  END IF;
END $$;

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS images_source_idx ON images(source);
CREATE INDEX IF NOT EXISTS images_source_metadata_idx ON images USING GIN(source_metadata);
