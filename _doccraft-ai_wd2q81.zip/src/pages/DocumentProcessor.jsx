import React, { useState, useEffect } from 'react'
import { useParams, Navigate } from 'react-router-dom'
import { useAuth } from '../contexts/AuthContext'
import { supabase } from '../lib/supabase'
import { FileText, Sparkles, Image, Settings, Download } from 'lucide-react'
import DocumentPreview from '../components/DocumentPreview'
import EnhancementPanel from '../components/EnhancementPanel'
import { 
  extractSectionSummary, 
  extractKeywords, 
  generateImagePrompt,
  generateMultipleImageSuggestions,
  calculateImageRelevance,
  getRelevanceLabel,
  getSourceLabel
} from '../utils/aiImageProcessor'
import { generateTopicFromSection } from '../lib/unsplash'
import toast from 'react-hot-toast'

const DocumentProcessor = () => {
  const { documentId } = useParams()
  const { user } = useAuth()
  const [document, setDocument] = useState(null)
  const [loading, setLoading] = useState(true)
  const [activeMode, setActiveMode] = useState('auto') // auto, hybrid, manual
  const [imageSource, setImageSource] = useState('both') // ai, stock, both
  const [enhancements, setEnhancements] = useState([])
  const [processing, setProcessing] = useState(false)

  useEffect(() => {
    fetchDocument()
  }, [documentId])

  useEffect(() => {
    // Reprocess enhancements when mode or image source changes
    if (document && document.status === 'processed') {
      reprocessEnhancementsForMode()
    }
  }, [activeMode, imageSource])

  const fetchDocument = async () => {
    try {
      const { data, error } = await supabase
        .from('documents')
        .select('*')
        .eq('id', documentId)
        .eq('user_id', user.id)
        .single()

      if (error) throw error
      setDocument(data)
      
      // Start AI analysis if not already processed
      if (data.status === 'uploaded') {
        await startAIAnalysis(data)
      } else if (data.enhancements) {
        const parsedEnhancements = JSON.parse(data.enhancements)
        setEnhancements(parsedEnhancements)
      }
    } catch (error) {
      toast.error('Error loading document')
    } finally {
      setLoading(false)
    }
  }

  const reprocessEnhancementsForMode = async () => {
    if (!document || !document.extracted_text) return

    setProcessing(true)
    try {
      const newEnhancements = await generateEnhancementsForMode(document.extracted_text, activeMode, imageSource)
      setEnhancements(newEnhancements)
      
      // Update document with new enhancements
      const { error } = await supabase
        .from('documents')
        .update({
          enhancements: JSON.stringify(newEnhancements)
        })
        .eq('id', document.id)

      if (error) throw error
    } catch (error) {
      console.error('Error reprocessing enhancements:', error)
      toast.error('Error updating enhancements for new mode')
    } finally {
      setProcessing(false)
    }
  }

  const startAIAnalysis = async (doc) => {
    setProcessing(true)
    
    try {
      const enhancements = await generateEnhancementsForMode(doc.extracted_text, activeMode, imageSource)
      
      // Update document with enhancements
      const { error } = await supabase
        .from('documents')
        .update({
          status: 'processed',
          enhancements: JSON.stringify(enhancements),
          processed_at: new Date().toISOString()
        })
        .eq('id', doc.id)

      if (error) throw error
      
      setEnhancements(enhancements)
      setDocument(prev => ({ ...prev, status: 'processed' }))
      toast.success('AI analysis completed!')
    } catch (error) {
      toast.error('Error processing document')
    } finally {
      setProcessing(false)
    }
  }

  const generateEnhancementsForMode = async (text, mode, source) => {
    // Simulate AI processing delay
    await new Promise(resolve => setTimeout(resolve, 2000))
    
    const sections = text.split('\n\n').filter(section => section.trim().length > 20)
    const enhancements = []

    for (let index = 0; index < Math.min(sections.length, 5); index++) {
      const section = sections[index]
      const sectionSummary = extractSectionSummary(section)
      const keywords = extractKeywords(section)
      
      // Skip sections with too little content
      if (!sectionSummary) {
        continue
      }

      const promptResult = generateImagePrompt(sectionSummary, keywords)
      
      if (promptResult.flagged) {
        // Flagged content - needs review
        enhancements.push({
          id: `enhancement-${index}`,
          type: 'visual_suggestion',
          section: section.substring(0, 200) + '...',
          sectionSummary,
          keywords,
          flagged: true,
          flagReason: promptResult.reason,
          confidence: 0,
          position: index * 2,
          approved: false
        })
      } else {
        // Generate image suggestions based on mode and source
        if (mode === 'hybrid') {
          const suggestions = await generateMultipleImageSuggestions(sectionSummary, keywords, 3, source)
          const enhancedSuggestions = suggestions.map((suggestion, idx) => {
            const relevance = suggestion.source === 'stock' 
              ? suggestion.confidence || 0.7
              : calculateImageRelevance(suggestion.prompt || suggestion.description, section, keywords)
            const relevanceInfo = getRelevanceLabel(relevance)
            
            return {
              ...suggestion,
              relevance,
              relevanceLabel: relevanceInfo.label,
              url: suggestion.url || `https://images.pexels.com/photos/${1000000 + index * 3 + idx}/pexels-photo-${1000000 + index * 3 + idx}.jpeg?auto=compress&cs=tinysrgb&w=400`,
              alt: suggestion.alt || `Illustration for section ${index + 1} - ${suggestion.style}`,
              description: suggestion.description || `${suggestion.style} representation: ${sectionSummary.substring(0, 100)}...`
            }
          })

          enhancements.push({
            id: `enhancement-${index}`,
            type: 'visual_suggestion',
            section: section.substring(0, 200) + '...',
            sectionSummary,
            keywords,
            suggestions: enhancedSuggestions,
            confidence: promptResult.confidence,
            position: index * 2,
            approved: false,
            flagged: false
          })
        } else {
          // Auto and Manual modes - single best suggestion
          let suggestedImage
          let relevance
          let confidence = promptResult.confidence

          if (source === 'stock') {
            // Generate stock image suggestion
            const topic = generateTopicFromSection(sectionSummary, keywords)
            const stockImages = await generateMultipleImageSuggestions(sectionSummary, keywords, 1, 'stock')
            
            if (stockImages.length > 0) {
              suggestedImage = {
                ...stockImages[0],
                description: `Professional stock photo: ${sectionSummary.substring(0, 100)}...`,
                alt: `Stock photo for section ${index + 1}`
              }
              relevance = stockImages[0].confidence || 0.7
              confidence = stockImages[0].confidence || 0.7
            } else {
              // Fallback to demo image
              suggestedImage = {
                description: `Professional stock photo: ${sectionSummary.substring(0, 100)}...`,
                url: `https://images.pexels.com/photos/${1000000 + index}/pexels-photo-${1000000 + index}.jpeg?auto=compress&cs=tinysrgb&w=400`,
                alt: `Stock photo for section ${index + 1}`,
                source: 'stock',
                sourceMetadata: { demo: true }
              }
              relevance = 0.6
            }
          } else {
            // AI-generated image suggestion
            suggestedImage = {
              description: `Professional illustration: ${sectionSummary.substring(0, 100)}...`,
              url: `https://images.pexels.com/photos/${1000000 + index}/pexels-photo-${1000000 + index}.jpeg?auto=compress&cs=tinysrgb&w=400`,
              alt: `Illustration for section ${index + 1}`,
              source: 'ai',
              sourceMetadata: { prompt: promptResult.prompt }
            }
            relevance = calculateImageRelevance(promptResult.prompt, section, keywords)
          }

          const relevanceInfo = getRelevanceLabel(relevance)
          
          enhancements.push({
            id: `enhancement-${index}`,
            type: 'visual_suggestion',
            section: section.substring(0, 200) + '...',
            sectionSummary,
            keywords,
            suggestion: promptResult.prompt,
            suggestedImage,
            confidence,
            relevance,
            relevanceLabel: relevanceInfo.label,
            position: index * 2,
            approved: mode === 'auto',
            flagged: false
          })
        }
      }
    }

    return enhancements
  }

  const handleEnhancementToggle = (enhancementId, approved, selectedImageIndex = null) => {
    setEnhancements(prev => 
      prev.map(enhancement => {
        if (enhancement.id === enhancementId) {
          const updated = { ...enhancement, approved }
          
          // If hybrid mode and image selected, set the selected image as primary
          if (selectedImageIndex !== null && enhancement.suggestions) {
            updated.selectedImageIndex = selectedImageIndex
            updated.suggestedImage = enhancement.suggestions[selectedImageIndex]
          }
          
          return updated
        }
        return enhancement
      })
    )
  }

  const handleCustomPrompt = async (enhancementId, prompt) => {
    try {
      // Simulate custom image generation
      await new Promise(resolve => setTimeout(resolve, 1000))
      
      setEnhancements(prev => 
        prev.map(enhancement => {
          if (enhancement.id === enhancementId) {
            return {
              ...enhancement,
              customPrompt: prompt,
              suggestedImage: {
                description: `Custom generated: ${prompt}`,
                url: `https://images.pexels.com/photos/${Math.floor(Math.random() * 1000000)}/pexels-photo-${Math.floor(Math.random() * 1000000)}.jpeg?auto=compress&cs=tinysrgb&w=400`,
                alt: 'Custom generated image',
                source: 'ai',
                sourceMetadata: { prompt, custom: true }
              },
              approved: true,
              flagged: false,
              confidence: 0.9,
              relevance: 0.8,
              relevanceLabel: 'Custom Match'
            }
          }
          return enhancement
        })
      )
      
      toast.success('Custom image generated!')
    } catch (error) {
      toast.error('Error generating custom image')
    }
  }

  const handleImageUpload = (enhancementId) => {
    // Create file input for image upload
    const input = document.createElement('input')
    input.type = 'file'
    input.accept = 'image/*'
    input.onchange = async (e) => {
      const file = e.target.files[0]
      if (!file) return

      try {
        // Upload to Supabase storage
        const fileExt = file.name.split('.').pop()
        const fileName = `${user.id}/custom-images/${Date.now()}.${fileExt}`
        
        const { data, error } = await supabase.storage
          .from('documents')
          .upload(fileName, file)

        if (error) throw error

        // Get public URL
        const { data: { publicUrl } } = supabase.storage
          .from('documents')
          .getPublicUrl(fileName)

        // Update enhancement with uploaded image
        setEnhancements(prev => 
          prev.map(enhancement => {
            if (enhancement.id === enhancementId) {
              return {
                ...enhancement,
                suggestedImage: {
                  description: `User uploaded: ${file.name}`,
                  url: publicUrl,
                  alt: 'User uploaded image',
                  source: 'upload',
                  sourceMetadata: { 
                    filename: file.name,
                    size: file.size,
                    type: file.type
                  }
                },
                approved: true,
                flagged: false,
                confidence: 1.0,
                relevance: 1.0,
                relevanceLabel: 'User Selected'
              }
            }
            return enhancement
          })
        )

        toast.success('Image uploaded successfully!')
      } catch (error) {
        toast.error('Error uploading image')
      }
    }
    input.click()
  }

  const handleImageSourceChange = (newSource) => {
    setImageSource(newSource)
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-accent-500"></div>
      </div>
    )
  }

  if (!document) {
    return <Navigate to="/dashboard" replace />
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Header */}
      <div className="mb-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="font-poppins text-3xl font-bold text-creative-calm-900 mb-2">
              {document.original_name}
            </h1>
            <div className="flex items-center space-x-4 text-creative-calm-600">
              <span className="flex items-center space-x-1">
                <FileText className="h-4 w-4" />
                <span>{document.file_type.toUpperCase()}</span>
              </span>
              <span className="flex items-center space-x-1">
                <Sparkles className="h-4 w-4" />
                <span className="capitalize">{document.status}</span>
              </span>
            </div>
          </div>
          
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2 bg-white rounded-lg border border-creative-calm-200 p-1">
              {['auto', 'hybrid', 'manual'].map((mode) => (
                <button
                  key={mode}
                  onClick={() => setActiveMode(mode)}
                  className={`px-3 py-1 rounded-md text-sm font-medium transition-colors ${
                    activeMode === mode
                      ? 'bg-accent-500 text-white'
                      : 'text-creative-calm-600 hover:text-creative-calm-900'
                  }`}
                >
                  {mode.charAt(0).toUpperCase() + mode.slice(1)}
                </button>
              ))}
            </div>
            
            <button className="btn-secondary flex items-center space-x-2">
              <Download className="h-4 w-4" />
              <span>Export</span>
            </button>
          </div>
        </div>
      </div>

      {/* Processing Status */}
      {processing && (
        <div className="card mb-8 bg-accent-50 border-accent-200">
          <div className="flex items-center space-x-3">
            <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-accent-500"></div>
            <div>
              <h3 className="font-medium text-accent-900">AI Analysis in Progress</h3>
              <p className="text-accent-700">
                {activeMode === 'hybrid' 
                  ? `Generating multiple ${imageSource === 'both' ? 'AI and stock' : imageSource} image options for each section...`
                  : `Analyzing content and generating intelligent ${imageSource === 'both' ? 'AI and stock' : imageSource} enhancement suggestions...`
                }
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Main Content */}
      <div className="grid lg:grid-cols-3 gap-8">
        {/* Document Preview */}
        <div className="lg:col-span-2">
          <DocumentPreview 
            document={document}
            enhancements={enhancements}
            mode={activeMode}
          />
        </div>

        {/* Enhancement Panel */}
        <div className="lg:col-span-1">
          <EnhancementPanel
            enhancements={enhancements}
            mode={activeMode}
            imageSource={imageSource}
            onToggleEnhancement={handleEnhancementToggle}
            onImageSourceChange={handleImageSourceChange}
            onCustomPrompt={handleCustomPrompt}
            onImageUpload={handleImageUpload}
            processing={processing}
          />
        </div>
      </div>
    </div>
  )
}

export default DocumentProcessor
