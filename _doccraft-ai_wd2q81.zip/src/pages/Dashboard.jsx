import React, { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { useAuth } from '../contexts/AuthContext'
import { supabase } from '../lib/supabase'
import { Upload, FileText, Clock, Sparkles } from 'lucide-react'
import FileUpload from '../components/FileUpload'
import toast from 'react-hot-toast'

const Dashboard = () => {
  const { user } = useAuth()
  const [documents, setDocuments] = useState([])
  const [loading, setLoading] = useState(true)
  const [showUpload, setShowUpload] = useState(false)

  useEffect(() => {
    fetchDocuments()
  }, [])

  const fetchDocuments = async () => {
    try {
      const { data, error } = await supabase
        .from('documents')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false })

      if (error) throw error
      setDocuments(data || [])
    } catch (error) {
      toast.error('Error fetching documents')
    } finally {
      setLoading(false)
    }
  }

  const handleUploadSuccess = (document) => {
    setDocuments(prev => [document, ...prev])
    setShowUpload(false)
    toast.success('Document uploaded successfully!')
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-accent-500"></div>
      </div>
    )
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h1 className="font-poppins text-3xl font-bold text-creative-calm-900 mb-2">
          Welcome back, {user.email}
        </h1>
        <p className="text-creative-calm-600">
          Upload and enhance your documents with AI-powered improvements
        </p>
      </div>

      {/* Upload Section */}
      <div className="mb-8">
        {!showUpload ? (
          <button
            onClick={() => setShowUpload(true)}
            className="btn-primary flex items-center space-x-2 text-lg px-6 py-3"
          >
            <Upload className="h-5 w-5" />
            <span>Upload New Document</span>
          </button>
        ) : (
          <div className="card">
            <div className="flex items-center justify-between mb-4">
              <h2 className="font-poppins text-xl font-semibold text-creative-calm-900">
                Upload Document
              </h2>
              <button
                onClick={() => setShowUpload(false)}
                className="text-creative-calm-400 hover:text-creative-calm-600"
              >
                Cancel
              </button>
            </div>
            <FileUpload onSuccess={handleUploadSuccess} />
          </div>
        )}
      </div>

      {/* Documents Grid */}
      <div className="grid gap-6">
        <h2 className="font-poppins text-2xl font-semibold text-creative-calm-900">
          Your Documents
        </h2>

        {documents.length === 0 ? (
          <div className="card text-center py-12">
            <FileText className="h-16 w-16 text-creative-calm-300 mx-auto mb-4" />
            <h3 className="font-poppins text-xl font-semibold text-creative-calm-900 mb-2">
              No documents yet
            </h3>
            <p className="text-creative-calm-600 mb-6">
              Upload your first document to get started with AI enhancement
            </p>
            <button
              onClick={() => setShowUpload(true)}
              className="btn-primary"
            >
              Upload Document
            </button>
          </div>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {documents.map((doc) => (
              <Link
                key={doc.id}
                to={`/process/${doc.id}`}
                className="card hover:shadow-lg transition-shadow duration-200 group"
              >
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center space-x-3">
                    <div className="p-2 bg-accent-100 rounded-lg">
                      <FileText className="h-6 w-6 text-accent-600" />
                    </div>
                    <div>
                      <h3 className="font-medium text-creative-calm-900 group-hover:text-accent-600 transition-colors">
                        {doc.original_name}
                      </h3>
                      <p className="text-sm text-creative-calm-500">
                        {doc.file_type.toUpperCase()}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-1 text-creative-calm-400">
                    <Clock className="h-4 w-4" />
                    <span className="text-xs">
                      {new Date(doc.created_at).toLocaleDateString()}
                    </span>
                  </div>
                </div>

                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <div className={`px-2 py-1 rounded-full text-xs font-medium ${
                      doc.status === 'processed' 
                        ? 'bg-green-100 text-green-700'
                        : doc.status === 'processing'
                        ? 'bg-yellow-100 text-yellow-700'
                        : 'bg-creative-calm-100 text-creative-calm-700'
                    }`}>
                      {doc.status}
                    </div>
                  </div>
                  <Sparkles className="h-4 w-4 text-accent-500 opacity-0 group-hover:opacity-100 transition-opacity" />
                </div>
              </Link>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}

export default Dashboard
