import React, { useState } from 'react'
import { useAuth } from '../contexts/AuthContext'
import { Navigate } from 'react-router-dom'
import { FileText, Sparkles, Image, Download } from 'lucide-react'
import AuthModal from '../components/AuthModal'
import toast from 'react-hot-toast'

const Home = () => {
  const { user } = useAuth()
  const [showAuthModal, setShowAuthModal] = useState(false)

  if (user) {
    return <Navigate to="/dashboard" replace />
  }

  const features = [
    {
      icon: FileText,
      title: 'Multi-Format Support',
      description: 'Upload PDF, DOCX, TXT, HTML, ODT, RTF, XLSX, and PPTX files'
    },
    {
      icon: Sparkles,
      title: 'AI Enhancement',
      description: 'Intelligent content analysis and improvement suggestions'
    },
    {
      icon: Image,
      title: 'Visual Integration',
      description: 'AI-generated images and visual suggestions for better clarity'
    },
    {
      icon: Download,
      title: 'Export Options',
      description: 'Export as PDF or create shareable HTML links'
    }
  ]

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <div className="relative overflow-hidden bg-gradient-to-br from-creative-calm-50 to-accent-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
          <div className="text-center">
            <h1 className="font-poppins text-5xl md:text-6xl font-bold text-creative-calm-900 mb-6">
              Transform Your Documents with{' '}
              <span className="text-accent-500">AI Magic</span>
            </h1>
            <p className="text-xl text-creative-calm-600 mb-8 max-w-3xl mx-auto">
              Upload any document and watch as AI enhances it with intelligent content improvements, 
              visual suggestions, and professional formatting. Make your documents shine.
            </p>
            <button
              onClick={() => setShowAuthModal(true)}
              className="btn-primary text-lg px-8 py-4 rounded-xl shadow-lg hover:shadow-xl transform hover:scale-105 transition-all duration-200"
            >
              Get Started Free
            </button>
          </div>
        </div>
      </div>

      {/* Features Section */}
      <div className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="font-poppins text-3xl font-bold text-creative-calm-900 mb-4">
              Powerful Features for Document Enhancement
            </h2>
            <p className="text-lg text-creative-calm-600 max-w-2xl mx-auto">
              Everything you need to create professional, visually appealing documents
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => (
              <div key={index} className="card text-center hover:shadow-lg transition-shadow duration-200">
                <div className="inline-flex items-center justify-center w-12 h-12 bg-accent-100 rounded-lg mb-4">
                  <feature.icon className="h-6 w-6 text-accent-600" />
                </div>
                <h3 className="font-poppins font-semibold text-lg text-creative-calm-900 mb-2">
                  {feature.title}
                </h3>
                <p className="text-creative-calm-600">
                  {feature.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* How It Works Section */}
      <div className="py-24 bg-creative-calm-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="font-poppins text-3xl font-bold text-creative-calm-900 mb-4">
              How It Works
            </h2>
            <p className="text-lg text-creative-calm-600">
              Three simple steps to enhanced documents
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                step: '01',
                title: 'Upload Document',
                description: 'Drag and drop your document or click to browse. We support all major formats.'
              },
              {
                step: '02',
                title: 'AI Analysis',
                description: 'Our AI analyzes your content and suggests improvements, visuals, and enhancements.'
              },
              {
                step: '03',
                title: 'Export & Share',
                description: 'Download your enhanced document as PDF or share via a beautiful HTML link.'
              }
            ].map((item, index) => (
              <div key={index} className="text-center">
                <div className="inline-flex items-center justify-center w-16 h-16 bg-accent-500 text-white font-bold text-xl rounded-full mb-4">
                  {item.step}
                </div>
                <h3 className="font-poppins font-semibold text-xl text-creative-calm-900 mb-2">
                  {item.title}
                </h3>
                <p className="text-creative-calm-600">
                  {item.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* CTA Section */}
      <div className="py-24 bg-accent-500">
        <div className="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8">
          <h2 className="font-poppins text-3xl font-bold text-white mb-4">
            Ready to Transform Your Documents?
          </h2>
          <p className="text-xl text-accent-100 mb-8">
            Join thousands of users who are creating better documents with AI
          </p>
          <button
            onClick={() => setShowAuthModal(true)}
            className="bg-white text-accent-500 font-semibold px-8 py-4 rounded-xl hover:bg-accent-50 transition-colors duration-200 shadow-lg"
          >
            Start Creating Now
          </button>
        </div>
      </div>

      <AuthModal 
        isOpen={showAuthModal} 
        onClose={() => setShowAuthModal(false)} 
      />
    </div>
  )
}

export default Home
