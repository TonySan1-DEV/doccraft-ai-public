import React, { useCallback, useState } from 'react'
import { useDropzone } from 'react-dropzone'
import { Upload, File, X, CheckCircle } from 'lucide-react'
import { useAuth } from '../contexts/AuthContext'
import { supabase } from '../lib/supabase'
import { extractTextFromFile } from '../utils/fileProcessors'
import toast from 'react-hot-toast'

const FileUpload = ({ onSuccess }) => {
  const { user } = useAuth()
  const [uploading, setUploading] = useState(false)
  const [uploadedFile, setUploadedFile] = useState(null)

  const onDrop = useCallback(async (acceptedFiles) => {
    const file = acceptedFiles[0]
    if (!file) return

    setUploading(true)
    setUploadedFile(file)

    try {
      // Verify user is authenticated from context first
      if (!user) {
        throw new Error('User not authenticated - please sign in')
      }

      console.log('Current user from context:', user.id)

      // Double-check authentication status
      const { data: { user: currentUser }, error: userError } = await supabase.auth.getUser()
      
      if (userError) {
        console.error('Auth error:', userError)
        throw new Error('Authentication error: ' + userError.message)
      }

      if (!currentUser) {
        throw new Error('No authenticated user found')
      }

      console.log('Current user from auth:', currentUser.id)

      // Extract text content
      let extractedText = ''
      try {
        extractedText = await extractTextFromFile(file)
      } catch (textError) {
        console.warn('Text extraction failed:', textError)
        // Continue with empty text rather than failing
      }
      
      // Upload file to Supabase Storage
      const fileExt = file.name.split('.').pop() || 'unknown'
      const fileName = `${currentUser.id}/${Date.now()}.${fileExt}`
      
      console.log('Uploading file to storage:', fileName)
      
      const { data: uploadData, error: uploadError } = await supabase.storage
        .from('documents')
        .upload(fileName, file)

      if (uploadError) {
        console.error('Storage upload error:', uploadError)
        throw new Error('File upload failed: ' + uploadError.message)
      }

      console.log('File uploaded successfully:', uploadData.path)

      // Prepare document data
      const documentData = {
        user_id: currentUser.id,
        filename: file.name,
        original_name: file.name,
        file_path: uploadData.path,
        file_type: fileExt.toLowerCase(),
        file_size: file.size,
        extracted_text: extractedText || null,
        status: 'uploaded'
      }

      console.log('Inserting document data:', documentData)

      // Insert document record
      const { data: docData, error: docError } = await supabase
        .from('documents')
        .insert(documentData)
        .select()
        .single()

      if (docError) {
        console.error('Database insert error:', docError)
        
        // Clean up uploaded file if database insert fails
        try {
          await supabase.storage
            .from('documents')
            .remove([uploadData.path])
        } catch (cleanupError) {
          console.warn('Failed to cleanup uploaded file:', cleanupError)
        }
        
        throw new Error('Failed to save document record: ' + docError.message)
      }

      console.log('Document saved successfully:', docData)
      
      onSuccess(docData)
      toast.success('Document uploaded successfully!')
      
    } catch (error) {
      console.error('Upload error:', error)
      toast.error('Error uploading file: ' + error.message)
    } finally {
      setUploading(false)
      setUploadedFile(null)
    }
  }, [user, onSuccess])

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'application/pdf': ['.pdf'],
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document': ['.docx'],
      'text/plain': ['.txt'],
      'text/html': ['.html'],
      'application/vnd.oasis.opendocument.text': ['.odt'],
      'application/rtf': ['.rtf'],
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': ['.xlsx'],
      'application/vnd.openxmlformats-officedocument.presentationml.presentation': ['.pptx']
    },
    maxFiles: 1,
    maxSize: 10 * 1024 * 1024, // 10MB
    disabled: uploading || !user
  })

  // Don't render if user is not authenticated
  if (!user) {
    return (
      <div className="w-full p-8 text-center border-2 border-dashed border-creative-calm-300 rounded-xl">
        <p className="text-creative-calm-600">Please sign in to upload documents</p>
      </div>
    )
  }

  return (
    <div className="w-full">
      <div
        {...getRootProps()}
        className={`border-2 border-dashed rounded-xl p-8 text-center cursor-pointer transition-colors ${
          isDragActive
            ? 'border-accent-500 bg-accent-50'
            : uploading
            ? 'border-creative-calm-300 bg-creative-calm-50 cursor-not-allowed'
            : 'border-creative-calm-300 hover:border-accent-400 hover:bg-accent-50'
        }`}
      >
        <input {...getInputProps()} />
        
        {uploading ? (
          <div className="space-y-4">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-accent-500 mx-auto"></div>
            <div>
              <p className="text-lg font-medium text-creative-calm-900">
                Processing {uploadedFile?.name}...
              </p>
              <p className="text-creative-calm-600">
                Extracting text and analyzing content
              </p>
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            <Upload className="h-12 w-12 text-creative-calm-400 mx-auto" />
            <div>
              <p className="text-lg font-medium text-creative-calm-900">
                {isDragActive ? 'Drop your file here' : 'Drag & drop your document'}
              </p>
              <p className="text-creative-calm-600">
                or click to browse files
              </p>
            </div>
            <div className="text-sm text-creative-calm-500">
              Supports: PDF, DOCX, TXT, HTML, ODT, RTF, XLSX, PPTX (max 10MB)
            </div>
          </div>
        )}
      </div>

      <div className="mt-4 text-xs text-creative-calm-500">
        <p>• Files are processed securely and stored encrypted</p>
        <p>• Text extraction happens locally in your browser when possible</p>
        <p>• AI analysis begins immediately after upload</p>
      </div>
    </div>
  )
}

export default FileUpload
