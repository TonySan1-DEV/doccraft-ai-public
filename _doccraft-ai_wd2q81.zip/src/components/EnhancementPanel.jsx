import React, { useState } from 'react'
import { Sparkles, Image, CheckCircle, XCircle, Clock, AlertTriangle, Upload, Edit3, Settings } from 'lucide-react'
import { getSourceLabel } from '../utils/aiImageProcessor'

const EnhancementPanel = ({ enhancements, mode, imageSource, onToggleEnhancement, onImageSourceChange, processing, onCustomPrompt, onImageUpload }) => {
  const [customPrompts, setCustomPrompts] = useState({})
  const [selectedImages, setSelectedImages] = useState({})

  const handleCustomPromptSubmit = (enhancementId, prompt) => {
    if (prompt.trim()) {
      onCustomPrompt(enhancementId, prompt.trim())
      setCustomPrompts(prev => ({ ...prev, [enhancementId]: '' }))
    }
  }

  const handleImageSelection = (enhancementId, imageIndex) => {
    setSelectedImages(prev => ({ ...prev, [enhancementId]: imageIndex }))
    onToggleEnhancement(enhancementId, true, imageIndex)
  }

  if (processing) {
    return (
      <div className="card">
        <div className="flex items-center space-x-3 mb-6">
          <Sparkles className="h-6 w-6 text-accent-500" />
          <h2 className="font-poppins text-xl font-semibold text-creative-calm-900">
            AI Analysis
          </h2>
        </div>
        
        <div className="text-center py-8">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-accent-500 mx-auto mb-4"></div>
          <p className="text-creative-calm-600">
            Analyzing document sections and generating intelligent visual suggestions...
          </p>
        </div>
      </div>
    )
  }

  return (
    <div className="card">
      <div className="flex items-center space-x-3 mb-6">
        <Sparkles className="h-6 w-6 text-accent-500" />
        <h2 className="font-poppins text-xl font-semibold text-creative-calm-900">
          AI Enhancements
        </h2>
      </div>

      {/* Image Source Toggle */}
      <div className="mb-6 p-4 bg-creative-calm-50 rounded-lg border border-creative-calm-200">
        <div className="flex items-center space-x-2 mb-3">
          <Settings className="h-4 w-4 text-creative-calm-600" />
          <span className="text-sm font-medium text-creative-calm-900">Image Source</span>
        </div>
        <div className="flex items-center space-x-2 bg-white rounded-lg border border-creative-calm-200 p-1">
          {[
            { value: 'ai', label: 'AI Only' },
            { value: 'stock', label: 'Stock Only' },
            { value: 'both', label: 'Both' }
          ].map((option) => (
            <button
              key={option.value}
              onClick={() => onImageSourceChange(option.value)}
              className={`px-3 py-1 rounded-md text-sm font-medium transition-colors ${
                imageSource === option.value
                  ? 'bg-accent-500 text-white'
                  : 'text-creative-calm-600 hover:text-creative-calm-900'
              }`}
            >
              {option.label}
            </button>
          ))}
        </div>
        <p className="text-xs text-creative-calm-500 mt-2">
          {imageSource === 'ai' && 'Generate custom illustrations using AI'}
          {imageSource === 'stock' && 'Use professional stock photos from Unsplash'}
          {imageSource === 'both' && 'Show options from both AI generation and stock photos'}
        </p>
      </div>

      {enhancements.length === 0 ? (
        <div className="text-center py-8 text-creative-calm-500">
          <Clock className="h-12 w-12 mx-auto mb-4 opacity-50" />
          <p>Enhancement suggestions will appear here</p>
        </div>
      ) : (
        <div className="space-y-6">
          {enhancements.map((enhancement) => (
            <div
              key={enhancement.id}
              className={`p-4 rounded-lg border transition-colors ${
                enhancement.approved
                  ? 'bg-green-50 border-green-200'
                  : enhancement.flagged
                  ? 'bg-yellow-50 border-yellow-200'
                  : 'bg-creative-calm-50 border-creative-calm-200'
              }`}
            >
              {/* Enhancement Header */}
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center space-x-2">
                  {enhancement.flagged ? (
                    <AlertTriangle className="h-4 w-4 text-yellow-600" />
                  ) : (
                    <Image className="h-4 w-4 text-accent-600" />
                  )}
                  <span className="text-sm font-medium text-creative-calm-900">
                    {enhancement.flagged ? 'Needs Review' : 'Visual Enhancement'}
                  </span>
                </div>
                
                {mode !== 'auto' && !enhancement.flagged && (
                  <div className="flex items-center space-x-2">
                    <button
                      onClick={() => onToggleEnhancement(enhancement.id, true)}
                      className={`p-1 rounded ${
                        enhancement.approved
                          ? 'text-green-600 bg-green-100'
                          : 'text-creative-calm-400 hover:text-green-600 hover:bg-green-100'
                      }`}
                    >
                      <CheckCircle className="h-4 w-4" />
                    </button>
                    <button
                      onClick={() => onToggleEnhancement(enhancement.id, false)}
                      className={`p-1 rounded ${
                        !enhancement.approved
                          ? 'text-red-600 bg-red-100'
                          : 'text-creative-calm-400 hover:text-red-600 hover:bg-red-100'
                      }`}
                    >
                      <XCircle className="h-4 w-4" />
                    </button>
                  </div>
                )}
              </div>

              {/* Section Summary */}
              <div className="mb-3 p-3 bg-white rounded border border-creative-calm-200">
                <p className="text-sm text-creative-calm-700 font-medium mb-1">Section Content:</p>
                <p className="text-sm text-creative-calm-600">
                  {enhancement.sectionSummary || enhancement.section}
                </p>
                {enhancement.keywords && enhancement.keywords.length > 0 && (
                  <div className="mt-2 flex flex-wrap gap-1">
                    {enhancement.keywords.slice(0, 5).map((keyword, idx) => (
                      <span key={idx} className="px-2 py-1 bg-accent-100 text-accent-700 text-xs rounded">
                        {keyword}
                      </span>
                    ))}
                  </div>
                )}
              </div>

              {/* Flagged Content */}
              {enhancement.flagged ? (
                <div className="bg-yellow-100 border border-yellow-200 rounded p-3 mb-3">
                  <p className="text-sm text-yellow-800 mb-2">
                    <strong>Review Required:</strong> {enhancement.flagReason}
                  </p>
                  {mode === 'manual' && (
                    <div className="space-y-2">
                      <input
                        type="text"
                        placeholder="Write a custom image prompt..."
                        value={customPrompts[enhancement.id] || ''}
                        onChange={(e) => setCustomPrompts(prev => ({ 
                          ...prev, 
                          [enhancement.id]: e.target.value 
                        }))}
                        className="w-full px-3 py-2 border border-yellow-300 rounded text-sm"
                      />
                      <button
                        onClick={() => handleCustomPromptSubmit(enhancement.id, customPrompts[enhancement.id])}
                        className="btn-primary text-sm py-1 px-3"
                        disabled={!customPrompts[enhancement.id]?.trim()}
                      >
                        Generate Image
                      </button>
                    </div>
                  )}
                </div>
              ) : (
                <>
                  {/* Image Suggestions */}
                  {mode === 'hybrid' && enhancement.suggestions ? (
                    <div className="space-y-3 mb-3">
                      <p className="text-sm font-medium text-creative-calm-900">Choose an image:</p>
                      <div className="grid grid-cols-1 gap-3">
                        {enhancement.suggestions.map((suggestion, idx) => {
                          const sourceInfo = getSourceLabel(suggestion.source)
                          return (
                            <div
                              key={idx}
                              className={`border rounded-lg p-3 cursor-pointer transition-colors ${
                                selectedImages[enhancement.id] === idx
                                  ? 'border-accent-500 bg-accent-50'
                                  : 'border-creative-calm-200 hover:border-accent-300'
                              }`}
                              onClick={() => handleImageSelection(enhancement.id, idx)}
                            >
                              <img
                                src={suggestion.thumbnailUrl || suggestion.url}
                                alt={suggestion.alt}
                                className="w-full h-24 object-cover rounded mb-2"
                                onError={(e) => {
                                  e.target.src = 'https://images.pexels.com/photos/1181671/pexels-photo-1181671.jpeg?auto=compress&cs=tinysrgb&w=400'
                                }}
                              />
                              <p className="text-xs text-creative-calm-600 mb-2">
                                {suggestion.description}
                              </p>
                              <div className="flex items-center justify-between mb-2">
                                <span className="text-xs text-accent-600 font-medium">
                                  Style: {suggestion.style}
                                </span>
                                <span className={`text-xs px-2 py-1 rounded-full ${
                                  suggestion.relevance >= 0.8 ? 'bg-green-100 text-green-700' :
                                  suggestion.relevance >= 0.6 ? 'bg-blue-100 text-blue-700' :
                                  suggestion.relevance >= 0.4 ? 'bg-yellow-100 text-yellow-700' :
                                  'bg-red-100 text-red-700'
                                }`}>
                                  {suggestion.relevanceLabel}
                                </span>
                              </div>
                              <div className="flex items-center justify-between">
                                <span className={`text-xs px-2 py-1 rounded ${sourceInfo.bg} ${sourceInfo.color}`}>
                                  {sourceInfo.label}
                                </span>
                                {suggestion.sourceMetadata?.attribution && (
                                  <span className="text-xs text-creative-calm-500 truncate max-w-32">
                                    {suggestion.sourceMetadata.photographer}
                                  </span>
                                )}
                              </div>
                            </div>
                          )
                        })}
                      </div>
                    </div>
                  ) : (
                    /* Single Image Display */
                    <div className="bg-white rounded-lg p-3 border border-creative-calm-200 mb-3">
                      <img
                        src={enhancement.suggestedImage.thumbnailUrl || enhancement.suggestedImage.url}
                        alt={enhancement.suggestedImage.alt}
                        className="w-full h-32 object-cover rounded mb-2"
                        onError={(e) => {
                          e.target.src = 'https://images.pexels.com/photos/1181671/pexels-photo-1181671.jpeg?auto=compress&cs=tinysrgb&w=400'
                        }}
                      />
                      <p className="text-xs text-creative-calm-500 mb-2">
                        {enhancement.suggestedImage.description}
                      </p>
                      {enhancement.relevance !== undefined && (
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-xs text-accent-600 font-medium">
                            Confidence: {Math.round(enhancement.confidence * 100)}%
                          </span>
                          <span className={`text-xs px-2 py-1 rounded-full ${
                            enhancement.relevance >= 0.8 ? 'bg-green-100 text-green-700' :
                            enhancement.relevance >= 0.6 ? 'bg-blue-100 text-blue-700' :
                            enhancement.relevance >= 0.4 ? 'bg-yellow-100 text-yellow-700' :
                            'bg-red-100 text-red-700'
                          }`}>
                            {enhancement.relevanceLabel}
                          </span>
                        </div>
                      )}
                      {enhancement.suggestedImage.source && (
                        <div className="flex items-center justify-between">
                          <span className={`text-xs px-2 py-1 rounded ${getSourceLabel(enhancement.suggestedImage.source).bg} ${getSourceLabel(enhancement.suggestedImage.source).color}`}>
                            {getSourceLabel(enhancement.suggestedImage.source).label}
                          </span>
                          {enhancement.suggestedImage.sourceMetadata?.attribution && (
                            <span className="text-xs text-creative-calm-500 truncate max-w-32">
                              {enhancement.suggestedImage.sourceMetadata.photographer}
                            </span>
                          )}
                        </div>
                      )}
                    </div>
                  )}

                  {/* Manual Mode Controls */}
                  {mode === 'manual' && (
                    <div className="space-y-3 pt-3 border-t border-creative-calm-200">
                      <div className="space-y-2">
                        <label className="text-sm font-medium text-creative-calm-900">
                          Custom Image Prompt:
                        </label>
                        <div className="flex space-x-2">
                          <input
                            type="text"
                            placeholder="Describe the image you want..."
                            value={customPrompts[enhancement.id] || ''}
                            onChange={(e) => setCustomPrompts(prev => ({ 
                              ...prev, 
                              [enhancement.id]: e.target.value 
                            }))}
                            className="flex-1 px-3 py-2 border border-creative-calm-300 rounded text-sm"
                          />
                          <button
                            onClick={() => handleCustomPromptSubmit(enhancement.id, customPrompts[enhancement.id])}
                            className="btn-secondary text-sm py-2 px-3 flex items-center space-x-1"
                            disabled={!customPrompts[enhancement.id]?.trim()}
                          >
                            <Edit3 className="h-3 w-3" />
                            <span>Generate</span>
                          </button>
                        </div>
                      </div>
                      
                      <div className="text-center">
                        <span className="text-sm text-creative-calm-500">or</span>
                      </div>
                      
                      <button
                        onClick={() => onImageUpload(enhancement.id)}
                        className="w-full btn-secondary text-sm py-2 flex items-center justify-center space-x-2"
                      >
                        <Upload className="h-4 w-4" />
                        <span>Upload Your Own Image</span>
                      </button>
                    </div>
                  )}
                </>
              )}

              {/* Status Footer */}
              <div className="mt-3 flex items-center justify-between text-xs">
                <span className="text-creative-calm-500">
                  Section {enhancement.position / 2 + 1}
                </span>
                <span className={`px-2 py-1 rounded-full ${
                  enhancement.approved
                    ? 'bg-green-100 text-green-700'
                    : enhancement.flagged
                    ? 'bg-yellow-100 text-yellow-700'
                    : 'bg-creative-calm-100 text-creative-calm-600'
                }`}>
                  {enhancement.approved ? 'Applied' : enhancement.flagged ? 'Needs Review' : 'Pending'}
                </span>
              </div>
            </div>
          ))}
        </div>
      )}

      {enhancements.length > 0 && (
        <div className="mt-6 pt-4 border-t border-creative-calm-200">
          <div className="text-sm text-creative-calm-600">
            <p className="mb-2">
              <strong>Mode:</strong> {mode.charAt(0).toUpperCase() + mode.slice(1)}
            </p>
            <p>
              {mode === 'auto' && 'Best suggestions are automatically applied based on content analysis'}
              {mode === 'hybrid' && 'Review multiple options and choose the best fit for each section'}
              {mode === 'manual' && 'Full control with custom prompts and image uploads'}
            </p>
          </div>
        </div>
      )}
    </div>
  )
}

export default EnhancementPanel
