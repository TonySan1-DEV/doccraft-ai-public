import React from 'react'
import { Link, useLocation } from 'react-router-dom'
import { useAuth } from '../contexts/AuthContext'
import { FileText, LogOut, User } from 'lucide-react'
import toast from 'react-hot-toast'

const Layout = ({ children }) => {
  const { user, signOut } = useAuth()
  const location = useLocation()

  const handleSignOut = async () => {
    const { error } = await signOut()
    if (error) {
      toast.error('Error signing out')
    } else {
      toast.success('Signed out successfully')
    }
  }

  return (
    <div className="min-h-screen">
      <nav className="bg-white border-b border-creative-calm-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex items-center">
              <Link to="/" className="flex items-center space-x-2">
                <FileText className="h-8 w-8 text-accent-500" />
                <span className="font-poppins font-bold text-xl text-creative-calm-900">
                  DocCraft-AI
                </span>
              </Link>
            </div>

            <div className="flex items-center space-x-4">
              {user ? (
                <>
                  <Link
                    to="/dashboard"
                    className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                      location.pathname === '/dashboard'
                        ? 'bg-accent-100 text-accent-700'
                        : 'text-creative-calm-600 hover:text-creative-calm-900'
                    }`}
                  >
                    Dashboard
                  </Link>
                  <div className="flex items-center space-x-2 text-creative-calm-600">
                    <User className="h-4 w-4" />
                    <span className="text-sm">{user.email}</span>
                  </div>
                  <button
                    onClick={handleSignOut}
                    className="flex items-center space-x-1 text-creative-calm-600 hover:text-creative-calm-900 transition-colors"
                  >
                    <LogOut className="h-4 w-4" />
                    <span className="text-sm">Sign Out</span>
                  </button>
                </>
              ) : (
                <div className="text-creative-calm-600 text-sm">
                  Welcome to DocCraft-AI
                </div>
              )}
            </div>
          </div>
        </div>
      </nav>

      <main className="flex-1">
        {children}
      </main>
    </div>
  )
}

export default Layout
