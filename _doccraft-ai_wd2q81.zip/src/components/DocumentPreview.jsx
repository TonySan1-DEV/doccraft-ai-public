import React from 'react'
import { Image, CheckCircle, XCircle, AlertTriangle } from 'lucide-react'
import { getSourceLabel } from '../utils/aiImageProcessor'

const DocumentPreview = ({ document, enhancements, mode }) => {
  const renderEnhancedContent = () => {
    if (!document.extracted_text) return null

    const paragraphs = document.extracted_text.split('\n\n').filter(p => p.trim())
    const approvedEnhancements = enhancements.filter(e => e.approved && !e.flagged)

    return paragraphs.map((paragraph, index) => {
      const enhancement = approvedEnhancements.find(e => e.position === index * 2)
      
      return (
        <div key={index} className="mb-6">
          <p className="text-creative-calm-700 leading-relaxed mb-4">
            {paragraph}
          </p>
          
          {enhancement && (
            <div className="my-6 p-4 bg-accent-50 rounded-lg border border-accent-200">
              <div className="flex items-start space-x-3">
                <div className="flex-shrink-0">
                  <Image className="h-5 w-5 text-accent-600 mt-1" />
                </div>
                <div className="flex-1">
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="font-medium text-accent-900">
                      AI Enhanced Visual
                    </h4>
                    <div className="flex items-center space-x-2">
                      {enhancement.relevanceLabel && (
                        <span className={`text-xs px-2 py-1 rounded-full ${
                          enhancement.relevance >= 0.8 ? 'bg-green-100 text-green-700' :
                          enhancement.relevance >= 0.6 ? 'bg-blue-100 text-blue-700' :
                          enhancement.relevance >= 0.4 ? 'bg-yellow-100 text-yellow-700' :
                          'bg-red-100 text-red-700'
                        }`}>
                          {enhancement.relevanceLabel}
                        </span>
                      )}
                      {enhancement.suggestedImage?.source && (
                        <span className={`text-xs px-2 py-1 rounded ${getSourceLabel(enhancement.suggestedImage.source).bg} ${getSourceLabel(enhancement.suggestedImage.source).color}`}>
                          {getSourceLabel(enhancement.suggestedImage.source).label}
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Section Summary */}
                  {enhancement.sectionSummary && (
                    <div className="mb-3 p-2 bg-white rounded border border-accent-100">
                      <p className="text-xs text-accent-700 font-medium mb-1">Content Analysis:</p>
                      <p className="text-xs text-creative-calm-600">
                        {enhancement.sectionSummary}
                      </p>
                      {enhancement.keywords && enhancement.keywords.length > 0 && (
                        <div className="mt-2 flex flex-wrap gap-1">
                          {enhancement.keywords.slice(0, 4).map((keyword, idx) => (
                            <span key={idx} className="px-1 py-0.5 bg-accent-100 text-accent-600 text-xs rounded">
                              {keyword}
                            </span>
                          ))}
                        </div>
                      )}
                    </div>
                  )}

                  <div className="bg-white rounded-lg p-3 border border-accent-200">
                    <img
                      src={enhancement.suggestedImage.thumbnailUrl || enhancement.suggestedImage.url}
                      alt={enhancement.suggestedImage.alt}
                      className="w-full h-48 object-cover rounded-lg mb-3"
                      onError={(e) => {
                        e.target.src = 'https://images.pexels.com/photos/1181671/pexels-photo-1181671.jpeg?auto=compress&cs=tinysrgb&w=400'
                      }}
                    />
                    <p className="text-sm text-creative-calm-600 mb-2">
                      {enhancement.suggestedImage.description}
                    </p>
                    
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <span className="text-xs text-accent-600 font-medium">
                          Confidence: {Math.round(enhancement.confidence * 100)}%
                        </span>
                        {enhancement.customPrompt && (
                          <span className="text-xs text-purple-600 bg-purple-100 px-2 py-1 rounded">
                            Custom
                          </span>
                        )}
                      </div>
                      
                      {mode !== 'auto' && (
                        <div className="flex items-center space-x-1">
                          <CheckCircle className="h-4 w-4 text-green-500" />
                          <span className="text-xs text-green-600">Applied</span>
                        </div>
                      )}
                    </div>

                    {/* Attribution for stock images */}
                    {enhancement.suggestedImage.sourceMetadata?.attribution && (
                      <div className="mt-2 pt-2 border-t border-accent-100">
                        <p className="text-xs text-creative-calm-500">
                          {enhancement.suggestedImage.sourceMetadata.attribution}
                        </p>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      )
    })
  }

  const flaggedCount = enhancements.filter(e => e.flagged).length
  const appliedCount = enhancements.filter(e => e.approved && !e.flagged).length

  return (
    <div className="card">
      <div className="flex items-center justify-between mb-6">
        <h2 className="font-poppins text-xl font-semibold text-creative-calm-900">
          Enhanced Document Preview
        </h2>
        <div className="flex items-center space-x-4 text-sm">
          <span className="text-green-600">
            {appliedCount} applied
          </span>
          {flaggedCount > 0 && (
            <span className="text-yellow-600 flex items-center space-x-1">
              <AlertTriangle className="h-3 w-3" />
              <span>{flaggedCount} need review</span>
            </span>
          )}
          <span className="text-creative-calm-500">
            of {enhancements.length} suggestions
          </span>
        </div>
      </div>

      <div className="prose max-w-none">
        {document.extracted_text ? (
          renderEnhancedContent()
        ) : (
          <div className="text-center py-12 text-creative-calm-500">
            <Image className="h-12 w-12 mx-auto mb-4 opacity-50" />
            <p>Document content will appear here after processing</p>
          </div>
        )}
      </div>
    </div>
  )
}

export default DocumentPreview
