// AI Image Processing utilities for enhanced relevance and section analysis
import { searchUnsplashImages, generateTopicFromSection } from '../lib/unsplash'

export const extractSectionSummary = (text, maxLength = 200) => {
  if (!text || text.trim().length < 50) {
    return null // Too little content
  }

  // Clean the text
  const cleanText = text
    .replace(/\s+/g, ' ')
    .replace(/[^\w\s.,!?-]/g, '')
    .trim()

  if (cleanText.length < 50) {
    return null
  }

  // Extract key sentences (first and most informative)
  const sentences = cleanText.split(/[.!?]+/).filter(s => s.trim().length > 20)
  
  if (sentences.length === 0) {
    return null
  }

  // Take first sentence and add context from second if needed
  let summary = sentences[0].trim()
  
  if (summary.length < 100 && sentences.length > 1) {
    const secondSentence = sentences[1].trim()
    if (summary.length + secondSentence.length < maxLength) {
      summary += '. ' + secondSentence
    }
  }

  return summary.length > maxLength ? summary.substring(0, maxLength) + '...' : summary
}

export const extractKeywords = (text) => {
  if (!text) return []

  // Common stop words to filter out
  const stopWords = new Set([
    'the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for', 'of', 'with',
    'by', 'from', 'up', 'about', 'into', 'through', 'during', 'before', 'after',
    'above', 'below', 'between', 'among', 'is', 'are', 'was', 'were', 'be', 'been',
    'being', 'have', 'has', 'had', 'do', 'does', 'did', 'will', 'would', 'could',
    'should', 'may', 'might', 'must', 'can', 'this', 'that', 'these', 'those'
  ])

  const words = text
    .toLowerCase()
    .replace(/[^\w\s]/g, ' ')
    .split(/\s+/)
    .filter(word => word.length > 3 && !stopWords.has(word))

  // Count word frequency
  const wordCount = {}
  words.forEach(word => {
    wordCount[word] = (wordCount[word] || 0) + 1
  })

  // Return top keywords sorted by frequency
  return Object.entries(wordCount)
    .sort(([,a], [,b]) => b - a)
    .slice(0, 10)
    .map(([word]) => word)
}

export const generateImagePrompt = (sectionSummary, keywords = []) => {
  if (!sectionSummary) {
    return null
  }

  // Check if content is too ambiguous
  const ambiguousIndicators = [
    'this', 'that', 'these', 'those', 'it', 'they', 'them',
    'such', 'various', 'different', 'many', 'some', 'several'
  ]

  const summaryWords = sectionSummary.toLowerCase().split(/\s+/)
  const ambiguousCount = summaryWords.filter(word => 
    ambiguousIndicators.includes(word)
  ).length

  // If too many ambiguous words, flag for review
  if (ambiguousCount > summaryWords.length * 0.3) {
    return {
      prompt: null,
      flagged: true,
      reason: 'Content too ambiguous for automatic image generation'
    }
  }

  // Generate contextual prompt
  const keywordContext = keywords.length > 0 
    ? ` Focus on themes related to: ${keywords.slice(0, 5).join(', ')}.`
    : ''

  const prompt = `Create a professional, clean illustration that visually represents: "${sectionSummary}".${keywordContext} Style: modern, minimalist, suitable for business documents. Avoid text overlays.`

  return {
    prompt,
    flagged: false,
    confidence: calculatePromptConfidence(sectionSummary, keywords)
  }
}

export const calculatePromptConfidence = (summary, keywords) => {
  if (!summary) return 0

  let confidence = 0.5 // Base confidence

  // Length factor (optimal around 50-150 characters)
  const length = summary.length
  if (length >= 50 && length <= 150) {
    confidence += 0.2
  } else if (length > 150 && length <= 200) {
    confidence += 0.1
  }

  // Keyword richness
  if (keywords.length >= 3) {
    confidence += 0.2
  } else if (keywords.length >= 1) {
    confidence += 0.1
  }

  // Specificity indicators
  const specificWords = [
    'technology', 'business', 'process', 'system', 'method', 'strategy',
    'analysis', 'research', 'development', 'management', 'design', 'solution'
  ]
  
  const hasSpecificTerms = specificWords.some(word => 
    summary.toLowerCase().includes(word)
  )
  
  if (hasSpecificTerms) {
    confidence += 0.1
  }

  return Math.min(confidence, 1.0)
}

export const generateMultipleImageSuggestions = async (sectionSummary, keywords, count = 3, imageSource = 'both') => {
  const suggestions = []
  
  // Generate AI suggestions
  if (imageSource === 'ai' || imageSource === 'both') {
    const basePrompt = generateImagePrompt(sectionSummary, keywords)
    
    if (basePrompt && !basePrompt.flagged) {
      // Generate variations of the prompt for different styles
      const aiVariations = [
        {
          ...basePrompt,
          style: 'illustration',
          prompt: basePrompt.prompt.replace('illustration', 'detailed illustration with soft colors'),
          source: 'ai'
        },
        {
          ...basePrompt,
          style: 'diagram',
          prompt: basePrompt.prompt.replace('illustration', 'clean diagram or infographic'),
          source: 'ai'
        },
        {
          ...basePrompt,
          style: 'conceptual',
          prompt: basePrompt.prompt.replace('illustration', 'conceptual artwork'),
          source: 'ai'
        }
      ]
      
      suggestions.push(...aiVariations.slice(0, imageSource === 'both' ? Math.ceil(count / 2) : count))
    }
  }
  
  // Generate stock image suggestions
  if (imageSource === 'stock' || imageSource === 'both') {
    try {
      const topic = generateTopicFromSection(sectionSummary, keywords)
      const stockCount = imageSource === 'both' ? Math.floor(count / 2) : count
      const stockImages = await searchUnsplashImages(topic, stockCount)
      
      suggestions.push(...stockImages.map(img => ({
        ...img,
        style: 'stock photo',
        confidence: calculateStockImageRelevance(img.description, sectionSummary, keywords)
      })))
    } catch (error) {
      console.error('Error fetching stock images:', error)
    }
  }
  
  return suggestions.slice(0, count)
}

export const calculateImageRelevance = (imageDescription, sectionText, keywords) => {
  if (!imageDescription || !sectionText) return 0

  const imageWords = imageDescription.toLowerCase().split(/\s+/)
  const sectionWords = sectionText.toLowerCase().split(/\s+/)
  
  // Keyword overlap score
  let keywordMatches = 0
  keywords.forEach(keyword => {
    if (imageDescription.toLowerCase().includes(keyword)) {
      keywordMatches++
    }
  })
  
  const keywordScore = keywords.length > 0 ? keywordMatches / keywords.length : 0

  // Semantic similarity (simplified - in production, use embeddings)
  const commonWords = imageWords.filter(word => 
    sectionWords.includes(word) && word.length > 3
  )
  
  const semanticScore = commonWords.length / Math.max(imageWords.length, sectionWords.length)

  // Combined relevance score
  return Math.min((keywordScore * 0.6 + semanticScore * 0.4), 1.0)
}

export const calculateStockImageRelevance = (imageDescription, sectionSummary, keywords) => {
  // For stock images, use a different relevance calculation
  const relevance = calculateImageRelevance(imageDescription, sectionSummary, keywords)
  
  // Stock images generally have good baseline relevance due to search matching
  return Math.max(relevance, 0.6)
}

export const getRelevanceLabel = (score) => {
  if (score >= 0.8) return { label: 'Excellent Match', color: 'text-green-600' }
  if (score >= 0.6) return { label: 'Good Match', color: 'text-blue-600' }
  if (score >= 0.4) return { label: 'Fair Match', color: 'text-yellow-600' }
  return { label: 'Poor Match', color: 'text-red-600' }
}

export const getSourceLabel = (source) => {
  switch (source) {
    case 'ai':
      return { label: 'Generated by AI', color: 'text-purple-600', bg: 'bg-purple-100' }
    case 'stock':
      return { label: 'From Unsplash', color: 'text-blue-600', bg: 'bg-blue-100' }
    case 'upload':
      return { label: 'User Upload', color: 'text-green-600', bg: 'bg-green-100' }
    default:
      return { label: 'Unknown Source', color: 'text-gray-600', bg: 'bg-gray-100' }
  }
}
