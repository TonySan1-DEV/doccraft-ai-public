import * as pdfjsLib from 'pdfjs-dist'
import mammoth from 'mammoth'
import * as XLSX from 'xlsx'
import JSZip from 'jszip'
import { convert } from 'html-to-text'

// Set up PDF.js worker
pdfjsLib.GlobalWorkerOptions.workerSrc = `//cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjsLib.version}/pdf.worker.min.js`

export const extractTextFromFile = async (file) => {
  const fileType = file.name.split('.').pop().toLowerCase()
  
  try {
    switch (fileType) {
      case 'pdf':
        return await extractFromPDF(file)
      case 'docx':
        return await extractFromDOCX(file)
      case 'txt':
        return await extractFromTXT(file)
      case 'html':
        return await extractFromHTML(file)
      case 'odt':
        return await extractFromODT(file)
      case 'rtf':
        return await extractFromRTF(file)
      case 'xlsx':
        return await extractFromXLSX(file)
      case 'pptx':
        return await extractFromPPTX(file)
      default:
        throw new Error(`Unsupported file type: ${fileType}`)
    }
  } catch (error) {
    console.error('Text extraction error:', error)
    throw new Error(`Failed to extract text from ${fileType.toUpperCase()} file`)
  }
}

const extractFromPDF = async (file) => {
  const arrayBuffer = await file.arrayBuffer()
  const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise
  let text = ''
  
  for (let i = 1; i <= pdf.numPages; i++) {
    const page = await pdf.getPage(i)
    const textContent = await page.getTextContent()
    const pageText = textContent.items.map(item => item.str).join(' ')
    text += pageText + '\n\n'
  }
  
  return text.trim()
}

const extractFromDOCX = async (file) => {
  const arrayBuffer = await file.arrayBuffer()
  const result = await mammoth.extractRawText({ arrayBuffer })
  return result.value
}

const extractFromTXT = async (file) => {
  return await file.text()
}

const extractFromHTML = async (file) => {
  const htmlContent = await file.text()
  return convert(htmlContent, {
    wordwrap: false,
    preserveNewlines: true
  })
}

const extractFromODT = async (file) => {
  // Basic ODT extraction - in production, you'd want a more robust solution
  const arrayBuffer = await file.arrayBuffer()
  const zip = await JSZip.loadAsync(arrayBuffer)
  const contentXml = await zip.file('content.xml').async('string')
  
  // Simple XML text extraction (remove tags)
  const textContent = contentXml.replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim()
  return textContent
}

const extractFromRTF = async (file) => {
  const rtfContent = await file.text()
  // Basic RTF text extraction (remove RTF codes)
  return rtfContent
    .replace(/\\[a-z]+\d*\s?/g, '') // Remove RTF control words
    .replace(/[{}]/g, '') // Remove braces
    .replace(/\s+/g, ' ') // Normalize whitespace
    .trim()
}

const extractFromXLSX = async (file) => {
  const arrayBuffer = await file.arrayBuffer()
  const workbook = XLSX.read(arrayBuffer, { type: 'array' })
  let text = ''
  
  workbook.SheetNames.forEach(sheetName => {
    const worksheet = workbook.Sheets[sheetName]
    const sheetText = XLSX.utils.sheet_to_txt(worksheet)
    text += `Sheet: ${sheetName}\n${sheetText}\n\n`
  })
  
  return text.trim()
}

const extractFromPPTX = async (file) => {
  // Basic PPTX extraction using JSZip
  const arrayBuffer = await file.arrayBuffer()
  const zip = await JSZip.loadAsync(arrayBuffer)
  let text = ''
  
  // Extract text from slide XML files
  const slideFiles = Object.keys(zip.files).filter(name => 
    name.startsWith('ppt/slides/slide') && name.endsWith('.xml')
  )
  
  for (const slideFile of slideFiles) {
    const slideXml = await zip.file(slideFile).async('string')
    // Extract text content from XML (basic approach)
    const slideText = slideXml
      .replace(/<[^>]*>/g, ' ')
      .replace(/\s+/g, ' ')
      .trim()
    text += slideText + '\n\n'
  }
  
  return text.trim()
}
